export class employeeData{

  id: number = 0;
  name:string="";
  mobile:string="";
  address:string=""
}






















